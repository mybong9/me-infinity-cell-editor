// Standalone AE2 + KubeJS export. The editor JAR is optional.
// Install startup/client scripts and restart once; later changes use /reload.
ServerEvents.recipes(event => {
  const catalogue = JsonIO.read('kubejs/config/me_infinity_editor/catalog.json');
  const output = global.meInfinityCell(catalogue["my_infinity_cell"]);
  const outputJson = {item: 'kubejs:me_infinity_cell', count: 1, nbt: output.nbt.toString()};
  if (Platform.isLoaded('me_infinity_editor')) event.custom({"type":"me_infinity_editor:catalog","result":outputJson}).id("me_infinity_editor:my_infinity_cell_catalog");
});
